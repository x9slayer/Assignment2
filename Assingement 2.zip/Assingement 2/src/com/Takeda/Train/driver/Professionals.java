package com.Takeda.Train.driver;

public class Professionals {
    public String First_name;
    public String Second_name;
    public String exp;

    public Professionals(String First_name,String Second_name, String exp) {
        this.First_name = First_name;
        this.Second_name= Second_name;
        this.exp = exp;
    }


}
