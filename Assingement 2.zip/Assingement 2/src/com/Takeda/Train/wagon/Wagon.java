package com.Takeda.Train.wagon;

public class Wagon {
    public double weight;
    public double volume;

    public Wagon(double weight, double volume) {
        this.weight = weight;
        this.volume = volume;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }

    public void setProduct(String product) {
    }

    public String getProduct() {
        return null;
    }

    public double totalWeight(){
        return weight;
    }

    public double getPower() {
        return getPower();
    }

    public int getPeople(){
        return 0;
    }

    public int getRooms(){
        return 0;
    }

    public double getCost(){
        return 0;
    }
}
